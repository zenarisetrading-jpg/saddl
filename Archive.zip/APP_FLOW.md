# PPC Optimizer - App Flow Document

**Version**: 1.0  
**Last Updated**: December 25, 2025

---

## Application Flow Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            USER ENTRY POINT                                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   First Time User              Returning User                                    │
│        │                            │                                            │
│        ▼                            ▼                                            │
│   Create Account ──────────► Select Account                                      │
│        │                            │                                            │
│        └────────────┬───────────────┘                                            │
│                     ▼                                                            │
│            ┌────────────────┐                                                    │
│            │   DATA HUB     │ ◄──── Upload or Auto-Load from DB                  │
│            └────────────────┘                                                    │
│                     │                                                            │
│                     ▼                                                            │
│   ┌─────────────────────────────────────────────────────────┐                   │
│   │                    MAIN DASHBOARD                        │                   │
│   │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │                   │
│   │  │  Home    │ │ Reports  │ │Optimizer │ │ Impact   │   │                   │
│   │  └──────────┘ └──────────┘ └──────────┘ └──────────┘   │                   │
│   └─────────────────────────────────────────────────────────┘                   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 1. Account Management Flow

### 1.1 New User Flow
```
App Launch
    │
    ▼
┌─────────────────┐
│ No accounts     │
│ detected        │
└─────────────────┘
    │
    ▼
┌─────────────────┐     ┌─────────────────┐
│ "Create New     │ ──► │ Enter Account   │
│  Account" CTA   │     │ Name            │
└─────────────────┘     └─────────────────┘
                              │
                              ▼
                        ┌─────────────────┐
                        │ Account Created │
                        │ + Selected      │
                        └─────────────────┘
                              │
                              ▼
                        ┌─────────────────┐
                        │ Redirect to     │
                        │ Data Hub        │
                        └─────────────────┘
```

### 1.2 Account Switching
```
Any Page
    │
    ▼
┌─────────────────┐
│ Sidebar:        │
│ Account Dropdown│
└─────────────────┘
    │
    ▼
Select Different Account
    │
    ▼
┌─────────────────┐
│ Clear Session   │ ← Prevents data bleed between accounts
│ State           │
└─────────────────┘
    │
    ▼
┌─────────────────┐
│ Load Account    │
│ Data from DB    │
└─────────────────┘
    │
    ▼
┌─────────────────┐
│ Redirect to     │
│ Home            │
└─────────────────┘
```

---

## 2. Data Upload Flow

### 2.1 Primary Upload Flow (Search Term Report)
```
Data Hub Page
    │
    ▼
┌─────────────────────┐
│ Search Terms        │
│ Uploader Widget     │
└─────────────────────┘
    │
    ▼ User drags/selects CSV/XLSX file
    │
┌─────────────────────┐
│ "I confirm this     │
│ belongs to [Account]"│
└─────────────────────┘
    │
    ▼ Checkbox confirmed
    │
┌─────────────────────┐
│ Processing...       │
│ ┌─────────────────┐ │
│ │ Column Detection│ │
│ │ Normalization   │ │
│ │ DB Save         │ │
│ └─────────────────┘ │
└─────────────────────┘
    │
    ├── Success ──► "✅ Saved X rows to database"
    │                    │
    │                    ▼
    │               ┌─────────────────┐
    │               │ System Ready    │
    │               │ All features on │
    │               └─────────────────┘
    │
    └── Failure ──► "❌ DATABASE SAVE FAILED!"
                         │
                         ▼
                    Data in memory only (lost on reload)
```

### 2.2 Supplementary Data Uploads
```
┌──────────────────────────────────────────────────────────────┐
│                       DATA HUB                                │
├────────────────┬────────────────┬────────────────────────────┤
│                │                │                            │
│ Advertised     │ Bulk ID Map    │ Category Map               │
│ Products       │                │                            │
│                │                │                            │
│ Maps campaigns │ Provides IDs   │ Groups SKUs into           │
│ to SKUs/ASINs  │ for bulk       │ categories for             │
│                │ exports        │ reporting                  │
│                │                │                            │
│ Optional       │ Optional       │ Optional                   │
└────────────────┴────────────────┴────────────────────────────┘
```

---

## 3. Optimization Workflow

### 3.1 Complete Optimization Flow
```
┌──────────────────────────────────────────────────────────────────────────┐
│                        OPTIMIZATION ENGINE                                │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  STEP 1: Date Selection                                                  │
│  ┌────────────────────────────────────────────────┐                     │
│  │  Start Date: [____]    End Date: [____]        │                     │
│  │  (Auto-populated from data range)              │                     │
│  └────────────────────────────────────────────────┘                     │
│                          │                                               │
│                          ▼                                               │
│  STEP 2: Configuration (Optional)                                        │
│  ┌────────────────────────────────────────────────┐                     │
│  │  Target ROAS: [3.5]  Target ACoS: [25%]        │                     │
│  │  Min Clicks: [3]     Min Spend: [5.0]          │                     │
│  └────────────────────────────────────────────────┘                     │
│                          │                                               │
│                          ▼                                               │
│  STEP 3: Run Analysis (Automatic)                                        │
│  ┌────────────────────────────────────────────────┐                     │
│  │  ► identify_harvest_candidates()              │                     │
│  │  ► identify_negative_candidates()             │                     │
│  │  ► calculate_bid_optimizations()              │                     │
│  │  ► run_simulation()                           │                     │
│  └────────────────────────────────────────────────┘                     │
│                          │                                               │
│                          ▼                                               │
│  STEP 4: Results Dashboard                                               │
│  ┌────────────────────────────────────────────────┐                     │
│  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐        │                     │
│  │  │112   │ │215   │ │93    │ │20    │        │                     │
│  │  │Touched│ │Bids  │ │Negs  │ │Harvest│       │                     │
│  │  └──────┘ └──────┘ └──────┘ └──────┘        │                     │
│  └────────────────────────────────────────────────┘                     │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Tab Navigation Flow
```
Optimization Results
    │
    ├─► Overview ─────► Summary metrics, Quick Actions
    │
    ├─► Defence ──────► Negative KWs, Negative PTs, Your Products Review
    │                   │
    │                   ▼
    │               Select items ──► Add to Export Queue
    │
    ├─► Bids ─────────► 4 Buckets: Exact, PT, Broad/Phrase, Auto
    │                   │
    │                   ▼
    │               Filter by action (Increase/Decrease)
    │               Select items ──► Add to Export Queue
    │
    ├─► Harvest ──────► Winner campaigns, SKU mapping
    │                   │
    │                   ▼
    │               Select items ──► Go to Campaign Creator
    │
    ├─► Audit ────────► Full data table with all targets
    │
    └─► Bulk Export ──► Generate & Download bulk files
```

---

## 4. Bulk Export Flow

### 4.1 Export Generation Flow
```
Bulk Export Tab
    │
    ▼
┌─────────────────────────────┐
│ Export Options:             │
│ □ Negatives (Keyword)       │
│ □ Negatives (PT)            │
│ □ Bid Updates               │
│ □ Harvest Keywords          │
└─────────────────────────────┘
    │
    ▼ Click "Generate Export"
    │
┌─────────────────────────────┐
│ Validation Engine:          │
│ • ID mapping check          │
│ • Duplicate detection       │
│ • Format validation         │
└─────────────────────────────┘
    │
    ├── Valid ──────► Generate XLSX file
    │                     │
    │                     ▼
    │                Download button appears
    │
    └── Issues ─────► Show validation warnings
                          │
                          ▼
                     User can still download
                     (with warnings noted)
```

### 4.2 File Upload to Amazon Flow (External)
```
Downloaded XLSX ──► Amazon Advertising Console
                         │
                         ▼
                    Bulk Operations ──► Upload
                         │
                         ▼
                    Amazon processes changes
                         │
                         ▼
                    Actions take effect in campaigns
```

---

## 5. Impact Tracking Flow

### 5.1 Action Logging (Automatic)
```
User clicks "Approve" or "Export"
    │
    ▼
┌─────────────────────────────┐
│ Log action to actions_log:  │
│ • client_id                 │
│ • action_type               │
│ • target_text               │
│ • campaign_name             │
│ • action_date               │
└─────────────────────────────┘
    │
    ▼
Action becomes trackable in Impact Dashboard
```

### 5.2 Impact Review Flow
```
Impact & Results Page
    │
    ▼
┌─────────────────────────────┐
│ Time Window Selection:      │
│ ○ 7D  ○ 14D  ● 30D  ○ 60D  │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ Fetch impact data:          │
│ • Before period metrics     │
│ • After period metrics      │
│ • Calculate deltas          │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│ Dashboard:                                       │
│ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────┐ │
│ │ Actions │ │ ROAS Δ  │ │ Revenue │ │ Impl % │ │
│ │  268    │ │ -6.6%   │ │ -$2,529 │ │  12%   │ │
│ └─────────┘ └─────────┘ └─────────┘ └────────┘ │
│                                                  │
│ [Waterfall Chart]  [Winners/Losers Chart]       │
│                                                  │
│ [Drill-Down Table with individual actions]      │
└─────────────────────────────────────────────────┘
```

---

## 6. Campaign Creator Flow

### 6.1 Harvest Campaign Creation
```
Campaign Creator ──► Harvest Tab
    │
    ▼
┌─────────────────────────────┐
│ Source: Optimizer harvest   │
│ candidates auto-populated   │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ Configure:                  │
│ • Portfolio ID              │
│ • Daily Budget              │
│ • Launch Date               │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ SKU Resolution:             │
│ (From Advertised Products)  │
└─────────────────────────────┘
    │
    ▼
Click "Generate Bulk File"
    │
    ▼
Download XLSX with:
• Campaigns (1 per SKU)
• Ad Groups (1 per keyword)
• Keywords (EXACT match)
• Product Ads
```

### 6.2 Cold Start Launch
```
Campaign Creator ──► Launch Tab
    │
    ▼
┌─────────────────────────────┐
│ Input:                      │
│ • SKU(s)                    │
│ • Target Price              │
│ • Target ACoS               │
│ • Seed Keywords (optional)  │
│ • Competitor ASINs (opt.)   │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ Tactics Selection:          │
│ ☑ Auto Campaign             │
│ ☑ Broad Match               │
│ ☑ Exact Match               │
│ ☑ Product Targeting         │
└─────────────────────────────┘
    │
    ▼
Click "Generate Structure"
    │
    ▼
Download XLSX with full campaign structure
```

---

## 7. Simulation Flow

### 7.1 Pre-Implementation Forecast
```
Simulator Page
    │
    ▼
┌─────────────────────────────┐
│ Prerequisite:               │
│ Optimizer must be run first │
└─────────────────────────────┘
    │
    ▼
Auto-loads optimization results
    │
    ▼
┌─────────────────────────────────────────────────┐
│ Simulation Display:                              │
│                                                  │
│ Current State          Projected State           │
│ ┌──────────────┐      ┌──────────────┐          │
│ │ Spend: X     │  ──► │ Spend: Y     │          │
│ │ Sales: X     │  ──► │ Sales: Y     │          │
│ │ ROAS: X      │  ──► │ ROAS: Y      │          │
│ └──────────────┘      └──────────────┘          │
│                                                  │
│ Confidence: [Low ──── Expected ──── High]       │
└─────────────────────────────────────────────────┘
```

---

## 8. AI Strategist Flow

### 8.1 Chat Interaction
```
AI Strategist Page
    │
    ▼
┌─────────────────────────────┐
│ Context automatically       │
│ loaded:                     │
│ • Account metrics           │
│ • Optimization results      │
│ • Recent performance        │
└─────────────────────────────┘
    │
    ▼
User types question
    │
    ▼
┌─────────────────────────────┐
│ AI Response with:           │
│ • Data-backed insights      │
│ • Specific recommendations  │
│ • Metric references         │
└─────────────────────────────┘
    │
    ▼
Conversation continues
(Context preserved in session)
```

---

## 9. Error States & Edge Cases

### 9.1 No Data Loaded
```
Any Module
    │
    ▼
┌─────────────────────────────┐
│ Data check fails            │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│ Empty State UI:                                  │
│                                                  │
│    📊 No Data Available                          │
│                                                  │
│    Upload a Search Term Report in Data Hub      │
│    to unlock this feature.                       │
│                                                  │
│    [Go to Data Hub]                             │
└─────────────────────────────────────────────────┘
```

### 9.2 Account Not Selected
```
Any Page
    │
    ▼
┌─────────────────────────────┐
│ active_account_id is None   │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│ Error Banner:                                    │
│                                                  │
│ ⚠️ No account selected!                          │
│ Please select or create an account in sidebar.  │
└─────────────────────────────────────────────────┘
```

### 9.3 Database Connection Failure
```
Any DB Operation
    │
    ▼
┌─────────────────────────────┐
│ Connection exception        │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────┐
│ Warning + Fallback:                              │
│                                                  │
│ ⚠️ Database connection failed.                   │
│ Working with session data only.                  │
│ Changes will not be persisted.                   │
└─────────────────────────────────────────────────┘
```

---

## 10. State Management

### 10.1 Session State Keys

| Key | Type | Purpose |
|-----|------|---------|
| `active_account_id` | str | Currently selected account |
| `active_account_name` | str | Display name |
| `unified_data` | dict | All loaded datasets |
| `optimizer_results` | dict | Harvest, Negative, Bid results |
| `simulation_results` | dict | Forecast projections |
| `active_opt_tab` | str | Current optimizer tab |

### 10.2 Data Flow Between Modules

```
Data Hub
    │
    ▼ Populates unified_data['search_term_report']
    │
Performance Snapshot ◄────────────────┐
    │                                  │
    │                                  │
Optimizer ◄────────────────────────────┤ Reads unified_data
    │                                  │
    ▼ Populates optimizer_results      │
    │                                  │
Simulator ◄────────────────────────────┤
    │                                  │
Campaign Creator ◄─────────────────────┤
    │                                  │
Bulk Export ◄──────────────────────────┘
    │
    ▼ Logs to actions_log table
    │
Impact Dashboard ◄─── Reads from actions_log + target_stats
```

---

## Appendix: Quick Reference Navigation

| From | To | Trigger |
|------|----|---------|
| Home | Data Hub | "Upload Data" button |
| Home | Optimizer | "Run Optimizer" button |
| Home | Impact | Nav menu |
| Data Hub | Performance | "Account Overview" CTA |
| Data Hub | Optimizer | "Run Optimizer" CTA |
| Optimizer Overview | Defence Tab | Tab click or Quick Action |
| Optimizer Overview | Harvest Tab | Tab click or Quick Action |
| Harvest Tab | Campaign Creator | "Create Campaigns" |
| Any Tab | Bulk Export | Tab click |
| Bulk Export | Download | Generate button |
